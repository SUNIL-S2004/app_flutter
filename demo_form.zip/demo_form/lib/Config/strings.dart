class Strings {
  Strings._();

//API URL
  static String baseURL = 'https://lgdirectory.gov.in/webservices/';
}
