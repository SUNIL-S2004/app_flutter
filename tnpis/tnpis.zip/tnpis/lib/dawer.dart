import 'main.dart';
import 'package:flutter/material.dart';

class Dawer_app extends StatelessWidget {
  const Dawer_app({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('menu'),
        backgroundColor: Colors.red,
      ),
      drawer: Drawer(
        elevation: 16.0,
        child: SafeArea(
          child: Column(
            children: <Widget>[
              Container(
                padding: EdgeInsets.all(16.0),
                width: double.infinity,
                color: Colors.red,
                child: Text(
                  'Info',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              ListTile(
                title: Text('xxxx'),
              ),
              Divider(
                height: 0.1,
              ),
              ListTile(
                title: Text('xxxx'),
              ),
              Divider(
                height: 0.1,
              ),
              ListTile(
                title: Text('xxxx'),
              ),
              Divider(
                height: 0.1,
              ),
              ListTile(
                title: Text('xxxx'),
              ),
              Divider(
                height: 0.1,
              ),
              ListTile(
                title: Text('xxxx'),
              ),
              Divider(
                height: 0.1,
              )
            ],
          ),
        ),
      ),
    );
  }
}
